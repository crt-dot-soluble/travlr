# Travlr Getaway Website

A travel agency website showcasing destinations, accommodations, and travel packages.

## Description

Travlr is a web application for a travel agency that allows users to browse travel destinations, accommodations, and special packages. The site includes information about rooms, meals, travel destinations, news, and contact information.

## Installation

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. Start the server:
   ```
   npm start
   ```
4. Open your browser and navigate to `http://localhost:3000`

## Features

- Responsive design
- Information about accommodations and travel destinations
- Contact form for inquiries
- News and updates section

## Technologies Used

- Node.js
- Express.js
- HTML5
- CSS3

## Project Structure

- `/public`: Static files (HTML, CSS, images)
- `server.js`: Express server configuration
